import requests
import csv


def download_proxy_list():
    url = 'https://api.proxyscrape.com/?request=getproxies&proxytype=socks5&timeout=10000&ssl=yes'
    response = requests.get(url)
    response.raise_for_status()
    print(f'Proxy list downloaded and saved to proxies.txt')
    return response.text

def test_proxy(proxy):
    url = 'https://www.google.com'
    proxies = {
        'http': f'socks5://{proxy}',
        'https': f'socks5://{proxy}',
    }
    try:
        response = requests.get(url, proxies=proxies, timeout=5)
        response.raise_for_status()
        return True
    except requests.RequestException:
        return False

def append_to_proxychains(proxy_list):
    proxychains_conf_path = '/etc/proxychains.conf'
    with open(proxychains_conf_path, 'r', encoding='utf-8') as file:
        existing_contents = file.read()
    formatted_proxies = [f"socks5 {proxy.split(':')[0]} {proxy.split(':')[1]}".replace('\r', '') for proxy in proxy_list.split('\n') if proxy and test_proxy(proxy)]
    new_contents = existing_contents + '\n' + '\n'.join(formatted_proxies) + '\n'
    with open(proxychains_conf_path, 'w', encoding='utf-8') as file:
        file.write(new_contents)
    print(f'Proxy list appended to {proxychains_conf_path}')

proxy_list = download_proxy_list()
append_to_proxychains(proxy_list)
